﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    public class Planet
    {
        public string Name { get; set; }
        public double Diameter { get; set; }
        public double DistanceFromSun { get; set; }
        public double Mass { get; set; }
        public double OrbitalPeriod { get; set; }
        public double Satellites { get; set; }
        public bool HasRings { get; set; }
        public bool HasLife { get; set; }

        public double GetGravity() // Вичислення гравітації планети
        {
            const double G = 6.67430e-11;
            double radius = Diameter / 2;
            double gravity = (G * Mass) / Math.Pow(radius * 1000, 2);
            return gravity;
        }
        public Planet()
        {

        }
        public Planet(string name, double diameter, double distanceFromSun,
            double mass, double orbitalPeriod, double satellites,
            bool hasRings, bool hasLife)
        {
            Name = name;
            Diameter = diameter;
            DistanceFromSun = distanceFromSun;
            Mass = mass;
            OrbitalPeriod = orbitalPeriod;
            Satellites = satellites;
            HasRings = hasRings;
            HasLife = hasLife;        
        }
    }

}
