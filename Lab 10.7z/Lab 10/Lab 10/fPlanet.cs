﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class fPlanet : Form
    {

        public Planet ThePlanet;

        public fPlanet(Planet t)
        {
            ThePlanet = t;
            InitializeComponent();
        }


        public fPlanet()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            ThePlanet.Name = tbName.Text.Trim();
            ThePlanet.Diameter = double.Parse(tbDiameter.Text.Trim());
            ThePlanet.DistanceFromSun = double.Parse(tbDistanceFromSun.Text.Trim());
            ThePlanet.Mass = double.Parse(tbMass.Text.Trim());
            ThePlanet.OrbitalPeriod = double.Parse(tbOrbitalPeriod.Text.Trim());
            ThePlanet.Satellites = double.Parse(tbSatellites.Text.Trim());
            ThePlanet.HasRings = chbHasRings.Checked;
            ThePlanet.HasLife = chbHasLife.Checked;
            
            DialogResult = DialogResult.OK;
        }

        private void fPlanet_Load(object sender, EventArgs e)
        {
            if (ThePlanet != null)
            {
                tbName.Text = ThePlanet.Name;
                tbDiameter.Text = ThePlanet.Diameter.ToString();
                tbDistanceFromSun.Text = ThePlanet.DistanceFromSun.ToString();
                tbMass.Text = ThePlanet.Mass.ToString("0.00e0");
                tbOrbitalPeriod.Text = ThePlanet.OrbitalPeriod.ToString();
                tbSatellites.Text = ThePlanet.Satellites.ToString();
                chbHasRings.Checked = ThePlanet.HasRings;
                chbHasLife.Checked = ThePlanet.HasLife;
            }
        }
    }
}
