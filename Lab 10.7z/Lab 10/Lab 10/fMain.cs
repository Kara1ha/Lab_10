﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class fMain : Form
    {
        public fMain()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Закрити застосунок?", "Вихід з програми",
                MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void toolTip6_Popup(object sender, PopupEventArgs e)
        {

        }

        private void fMain_Load(object sender, EventArgs e)
        {
            gvPlanets.AutoGenerateColumns = false;
            DataGridViewColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Name";
            column.Name = "Назва";
            gvPlanets.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Diameter";
            column.Name = "Діаметр";
            gvPlanets.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "DistanceFromSun";
            column.Name = "Дистанція до сонця";
            gvPlanets.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Mass";
            column.Name = "Масса";
            gvPlanets.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "OrbitalPeriod";
            column.Name = "Орбітальний період";
            gvPlanets.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Satellites";
            column.Name = "Кількість супутників";
            column.Width = 80;
            gvPlanets.Columns.Add(column);
            column = new DataGridViewCheckBoxColumn();
            column.DataPropertyName = "HasRings";
            column.Name = "Кільця";
            column.Width = 60;
            gvPlanets.Columns.Add(column);
            column = new DataGridViewCheckBoxColumn();
            column.DataPropertyName = "HasLife";
            column.Name = "Життя";
            column.Width = 60;
            gvPlanets.Columns.Add(column);
            bindSrcPlanets.Add(new Planet("Марс", 1000000, 4, 5.987e24, 3, 0, false, true));
            EventArgs args = new EventArgs();
            OnResize(args);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Planet planet = new Planet();
            
            fPlanet ft = new fPlanet(planet);
            
            if (ft.ShowDialog() == DialogResult.OK)
            {
                bindSrcPlanets.Add(planet);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Planet planet = (Planet)bindSrcPlanets.List[bindSrcPlanets.Position];
            fPlanet ft = new fPlanet(planet);
            if (ft.ShowDialog() == DialogResult.OK)
            {
                bindSrcPlanets.List[bindSrcPlanets.Position] = planet;
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            {
                if (MessageBox.Show("Видалити поточний запис?",
                "Видалення запису", MessageBoxButtons.OKCancel,
                MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    bindSrcPlanets.RemoveCurrent();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                "Очистити таблицю?\n\nВсі дані будуть втрачені",
                "Очищення даних", MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question) == DialogResult.OK)
            {
                bindSrcPlanets.Clear();
            }
        }
    }
}
